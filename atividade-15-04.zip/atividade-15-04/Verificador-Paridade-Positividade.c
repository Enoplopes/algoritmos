/* =====================================
* 	Nome do Programa: Verificador-paridade-positividade.c
*
*
* 	Obijetivo: informar se o numero � positivo ou negativo,
*	e se � zero
*
* 	Autor: Eno Paz Lopes
*
*	Data de cria��o: 15/04/2026
*
* =======================================*/
#include <stdio.h>
#include <conio.h> 
#include <locale.h>

int main () {

	setlocale(LC_ALL, "Portuguese");
	int num;
	
	
	printf("digite um numero: "); // para pedir o numero
	scanf("%d", &num); // para armazenar o numero
	
	if ( num == 0) { // testar se � zero
		printf("numero � zero");
	} else if ( num > 0) { // verifica se o numero � positivo ou negativo
		printf("o n�mero %d � positivo", num);
	} else {
		printf("o n�mero %d � negativo", num);
	}
	if (num % 2 == 0) { // verifica se o � numero par ou impar
		printf(" e � par", num);
	} else {
	printf(" e � �mpar", num);
	}
	
	getch (); // usado para nao fechar instantaneamente apor terminar
}
