/* =====================================
* 	Nome do Programa: classifica��o-de-triangulos.c
*
*
* 	Obijetivo: classificar qual tipo de triangulo:
*	equilatero, is�celes, escaleno.
*
* 	Autor: Eno Paz Lopes
*
*	Data de cria��o: 15/04/2026
*
* =======================================*/

#include <stdio.h>
#include <conio.h> 
#include <locale.h>

int main () {

	setlocale(LC_ALL, "Portuguese");
	float lado01, lado02, lado03;
	
	printf("digite o primeiro lado do triangulo: ");
	scanf("%f", &lado01);
	
	printf("digite o segundo lado do triangulo: ");
	scanf("%f", &lado02);
	
	printf("digite o terceiro lado do triangulo: ");
	scanf("%f", &lado03);
	
	if( (lado01 + lado02) > lado03 && (lado01 + lado03) > lado02 && (lado02 + lado03) > lado01 ){
		
	 if (lado01 == lado02 && lado02 == lado03){
		printf("triangulo equilatero");
	} else if (lado01 == lado02 || lado01 == lado03 || lado02 == lado03) {
		printf("triangulo is�celes");
	}else if (lado01 != lado02 != lado03){
		printf("triangulo escaleno");
	}
}else {
	printf("triangulo invalido");
}
	
	getch();
	
	
}
