/* =====================================
* 	Nome do Programa: temperatura-mate.c
*
*
* 	Obijetivo: informar como esta a temperatura da agua,
*	se esta na temperatura ideal, muito fria ou muito quente
*
* 	Autor: Eno Paz Lopes
*
*	Data de cria��o: 15/04/2026
*
* =======================================*/
#include <stdio.h>
#include <conio.h> 
#include <locale.h>

int main () {

	setlocale(LC_ALL, "Portuguese");
	int num;
	
	printf("digite a temperatura da �gua: "); //pedir a temperatura
	scanf("%d", &num); // ler a temperatura
	
	if (num > 70 && num < 80) { // verificar se esta na temperatura ideal
		printf("temperatura ideal para o mate", num);
	}else  if (num < 70) { // verificar se esta muito fria a agua
		printf("�gua muito fria", num);
	}else  if (num > 80) { // verificar se esta muito quente a agua
		printf("�gua muito quente, vai queimar a erva!", num);
	}
	
	getch(); // usado para nao fechar instantaneamente apor terminar
	
}
