/* =====================================
* 	Nome do Programa: calculadora-de-desconto-academico.c
*
*
* 	Obijetivo: dar o desconto para o aluno da universidade
*
* 	Autor: Eno Paz Lopes
*
*	Data de cria��o: 15/04/2026
*
* =======================================*/

#include <stdio.h>
#include <conio.h> 
#include <locale.h>
#include <stdbool.h>

int main () {

	setlocale(LC_ALL, "Portuguese");
	
	float valor; 
	int pagamento = 200;
	bool indicador;
	int monitor;
	
	

	printf("valor da mensalidade");
	scanf("%f", &valor);
	
	printf("pagamento � vista ou parcelado? ('1' para � vista e '2' para parcelado): ");
	scanf("%d", &pagamento);

	
	printf("o aluno � monitor de alguma disciplina? (1 para sim, 0 para nao): ");
	scanf("%d", &monitor);
	
	
	
	if (pagamento == 1){
		valor = valor * 0.90;
		printf("o valor a ser pago �: %.2f", valor);		
	}else {
		printf("valor a ser pago �: %.2f", valor);
	}
	if (monitor == 1){
		valor = valor * 0.95;
		printf("valor a ser pago �: %.2f", valor);
	}else{
		printf("valor a ser pago �: %.2f", valor);
	}
	
	
getch()
	
}
