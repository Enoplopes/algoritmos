/* =====================================
* 	Nome do Programa: aprova��o-simples.c
*
*
* 	Obijetivo: infomar se o aluno esta aprovado
*	ou reprovado, ou em exame.
*
* 	Autor: Eno Paz Lopes
*
*	Data de cria��o: 15/04/2026
*
* ======================================*/
#include <stdio.h>
#include <conio.h> 
#include <locale.h>

int main () {

	setlocale(LC_ALL, "Portuguese");
	float num;
	
	printf("digite a nota: "); // pedir a nota do aluno
	scanf("%f", &num); // ler a nota
	
	if (num < 0 && num > 10) { // verificar se a nota � valida
		printf("nota invalida");
	} else if (num < 5) { // verificar se o aluno esta reprovado
		printf("Reprovado!");
	} else if (num >= 7){ // verificar se o aluno esta aprovado
		printf("Aprovado!");
	} else  {
		printf("Em exame"); // verificar se o aluno ficou em exame
	}

getch(); // usado para nao fechar instantaneamente apor terminar

	
}
