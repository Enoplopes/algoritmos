/*=========================================================
*
*	Nome do progroma: : media das notas
*
*	objetivo: criar uma matriz com as 4 medias das notas digitadas
*	
*
*	autor: Eno Paz Lopes
*		
*	data de cria��o 03/06/2026
*
==========================================================*/

#include <stdio.h>

int main(){
	float matriz [4][4];
	int i, j;
	float soma;
	
	for(i = 0; i <4; i++){
		printf("digite a nota da disciplina %d\n", i+1);
		for(j = 0; j < 4; j++){
			printf("nota %d: ", j+1);
			scanf("%f", &matriz[i][j]);
		}
	}
	for(i = 0; i <4; i++){
		soma = 0;
		for(j = 0; j < 4; j++){
			soma = soma + matriz[i][j];
		}
		printf("disciplina %d media: %f \n", i+1, soma / 4);
	}
	
	
	
	
	
	
	
	
	
	
	return 0;
}
