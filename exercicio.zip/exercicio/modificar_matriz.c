/*=========================================================
*
*	Nome do progroma: : modificar a matriz
*
*	objetivo: modificar um valor da matriz
*	
*
*	autor: Eno Paz Lopes
*		
*	data de cria��o 03/06/2026
*
==========================================================*/
#include <stdio.h>

int main(){
	int matriz[3][4] = {0}; 
    int linha, coluna, novo_valor;

    printf("Digite a linha (0 a 2): ");
    scanf("%d", &linha);
    printf("Digite a coluna (0 a 3): ");
    scanf("%d", &coluna);

    if (linha >= 0 && linha < 3 && coluna >= 0 && coluna < 4) {
        printf("Digite o novo valor para a posicao [%d][%d]: ", linha, coluna);
        scanf("%d", &novo_valor);
        
        matriz[linha][coluna] = novo_valor;
        printf("Valor alterado com sucesso!\n");
    } else {
        printf("Erro: Indices fora do limite da matriz! Acesso negado.\n");
    }
	
	
	
	
	return 0;
}
