/*=========================================================
*
*	Nome do progroma: : media das notas
*
*	objetivo: criar uma matriz com as 4 medias das notas digitadas
*	
*
*	autor: Eno Paz Lopes
*		
*	data de cria��o 03/06/2026
*
==========================================================*/

#include <stdio.h>


int main(){
	
	int matrizA[3][3];
	int matrizB[3][3];
	int i, j;
	
	printf("preencha a matriz A (3x3): ");
	for(i = 0; i < 3; i++){
		for(j = 0; j < 3; j++){
			printf("valor [%d] [%d]: ", i, j);
			scanf("%d", &matrizA[i][j]);
		}
	}
	for(i = 0; i < 3; i++){
		for(j = 0; j < 3; j++){
			matrizB[j][i] = matrizA[i][j];
		}
}
	printf("matriz trasposta B: \n");
	for(i = 0; i < 3; i++){
		for(j = 0; j < 3; j++){
			printf("%d ", matrizB[i][j]);
			
		}
		printf("\n");
	}




	
	return 0;
}
