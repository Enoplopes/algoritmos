/*=========================================================
*
*	Nome do progroma: : prucurando numero na matriz
*
*	objetivo: criar uma matriz 3 por 3 e procurar um numero dentro delas
*	
*
*	autor: Eno Paz Lopes
*		
*	data de cria��o 03/06/2026
*
==========================================================*/
#include <stdio.h>

int main(){
	
	
	int matriz [3][3] = {
	{1, 2, 3},
	{4, 5, 6},
	{7, 8, 9}
	};
	int i, j;
	int procurado;
	int encontrado = 0;
	
	for(i = 0; i < 3; i++){
		for(j = 0; j < 3; j++){
			printf("%d ", matriz[i][j]);
		}
		printf("\n");
	}
	printf("digite o numero procurado: ");
			scanf("%d", &procurado);
	for(i = 0; i < 3; i++){
		for(j = 0; j < 3; j++){
			if(procurado == matriz[i][j]){
				printf("numero procurado %d esta na linha %d e na coluna %d", procurado, i, j);
				encontrado = 1;
			} 
			}
		}
	if(encontrado == 0) {
        printf("Numero nao encontrado\n");
    }
	
	return 0;
}
