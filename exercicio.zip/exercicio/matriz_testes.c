/*=========================================================
*
*	Nome do progroma: : matriz das notas
*
*	objetivo: criar uma matriz com as 4 notas bimestrais de 4 materias
*	
*
*	autor: Eno Paz Lopes
*		
*	data de cria��o 03/06/2026
*
==========================================================*/

#include <stdio.h>

int main(){
	float matriz [4][4];
	int i, j;
	
	for(i = 0; i <4; i++){
		printf("digite a nota da disciplina %d\n", i+1);
		for(j = 0; j < 4; j++){
			printf("nota %d: ", j+1);
			scanf("%f", &matriz[i][j]);
		}
	}
	for(i = 0; i <4; i++){
		printf("disciplina %d  ", i+1);
		for(j = 0; j < 4; j++){
			printf("nota %d: %2.f  ", j+1, matriz[i][j]);
		}
		printf("\n");
	}
	
	
	
	
	
	
	
	
	
	
	return 0;
}
