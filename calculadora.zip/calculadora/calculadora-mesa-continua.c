#include <stdio.h>
#include <locale.h>

main (void) {
	setlocale(LC_ALL, "Portuguese");

	float valor = 0;
	float  resultado = 0, num;
	int opcao;
	
	printf("calculadora de mesa continua: \n");
	
	
	do {
		
		printf("valor acumulado %f \n", resultado);
		printf("escolha uma das op��es: 1- Soma / 2- Subtra��o / 3- Divis�o / 4- multiplic�o / 5- Sair \n");
		scanf("%d", &opcao);
		
		
		
		switch (opcao) {
			case 1:
			printf("digite seu primeiro numero:");
		scanf("%f", &num);
			valor = valor + num;
			resultado = valor;
			break;
			
			case 2:
				printf("digite seu primeiro numero:");
		scanf("%f", &num);
			valor = valor - num;
			resultado = valor;
		
			break;
			
			case 3:
				printf("digite seu primeiro numero:");
		scanf("%f", &num);
				if (num == 0){
					puts("divis�o invalida");
				} else {
				
			valor = valor / num;
			resultado = valor;
		}
			break;
			
			case 4:
				printf("digite seu primeiro numero:");
		scanf("%f", &num);
			valor = valor * num;
			resultado = valor;
			break;
			
			case 5:
			
			puts("fim do programa!");
			break;
				
			default:
			printf("operador invalido \n");
			
		}
		
		
	}while (opcao != 5);
	printf("resultado: %f \n", resultado);	
	
	
	
	
	
	
	return 0;
}
