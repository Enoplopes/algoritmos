#include <stdio.h>

int main(){
	
	int vetor[10];
	int i;
	
	
	printf("Digite 10 numeros: \n");
	
	for( i = 0 ; i < 10 ; i++){
		printf("Valor %d: ", i + 1);
		scanf("%d", &vetor[i]);
		if(vetor[i] < 0){
			vetor[i] = 0;
		}
	}
	for( i = 0 ; i < 10 ; i++){
		printf("posicao %d, indice %d do vetor: %d \n", (i+1), i,vetor[i]);
	}
	
	
	
	
	
	return 0;
}
