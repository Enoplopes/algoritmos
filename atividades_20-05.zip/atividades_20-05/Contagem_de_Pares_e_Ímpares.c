#include <stdio.h>

int main(){
	
	int vetor[10];
	int par = 0;
	int impar = 0;
	int i;
	printf("Digite 10 numeros: \n");
	
	for( i = 0 ; i < 10 ; i++){
		printf("numero %d:", i + 1);
		scanf("%d", &vetor[i]);
		
	}
	for ( i = 0 ; i < 10 ; i++){
		if(vetor[i] % 2 == 0){
			par++;
		} else {
			impar++;
		}
	}
	printf("qauntidade de numeros par: %d \n", par);
	printf("quantidade de numeros impar: %d", impar);
	
	
	return 0;
}
