#include <stdio.h>

int main(){

float vetor[5];
float soma = 0;
int i;

printf("digite 5 numeros: \n ");

	for(i = 0; i < 5; i++) {
        printf("Valor %d:  ", i + 1);
        scanf("%f", &vetor[i]);
	
	soma += vetor[i];
	
}
	printf("a soma de todos os elementos eh: %f.2 \n ", soma);

	return 0;
}
