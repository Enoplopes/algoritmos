#include <stdio.h>

int main(){
	int vetor [6];
	int  i;
	
	printf("Digite 6 numeros: \n");
	
	for ( i = 0  ; i < 6; i++ ){
		printf("valor %d: ",i + 1);
		scanf("%d", &vetor[i]);
	}
	for( i = 5 ; i >= 0 ; i--){
	printf("posicao %d, indice %d do vetor: %d \n", (i+1), i,vetor[i]);
	}
	
	
	return 0;
}
