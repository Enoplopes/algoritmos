#include <stdio.h>
#include <stdbool.h>

int main(){
	
	int vetor[8];
	int procurado;
	int i;
	bool v = false;
	
	printf("Digite 8 numeros inteiros: \n");
	
	for( i = 0 ; i < 8 ; i++){
		printf("Valor %d: ", i + 1);
		scanf("%d", &vetor[i]);
	}
	printf("Digite o numero que voce procura: ");
	scanf("%d", &procurado);
	
	for( i = 0 ; i < 8 ; i++){
		if(vetor[i] == procurado){
			printf("o numero procurado esta no indice %d", vetor[i]);
			v = true;
		}
		
	}
	if (v == false){
		printf("numero nao encontrado");
	}
	
	
	
	
	return 0;
}
