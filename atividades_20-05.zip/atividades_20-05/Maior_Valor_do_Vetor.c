#include <stdio.h>

int main(){
	
	int vetor[8];
	int i;
	int maior;
	
	printf("Digite 8 numeros: \n");
	
	for (i = 0 ; i < 8 ; i++){
		printf("valor %d: ",i + 1);
		scanf("%d", &vetor[i]);	
	}
	
	maior = vetor[0];
	
	for( i = 1 ; i < 8 ; i++){
		if( vetor[i] > maior){
			maior = vetor[i];
		}
	}
	printf("o maior numero digitado eh: %d", maior);
	
	return 0;
}
