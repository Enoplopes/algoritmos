#include <stdio.h>

int main(){
	int vetor [5];
	int  i;
	
	for ( i = 0  ; i < 5; i++ ){
		puts("Digite um numero inteiro: ");
		scanf("%d", &vetor[i]);
	}
	for ( i = 0; i < 5 ; i++){
		printf("posicao %d, indice %d do vetor: %d \n", (i+1), i,vetor[i]);
	}
	
	return 0;
}
