/*=========================================================
*
*	Nome do progroma: : Soma e M�dia dos Elementos
*
*	objetivo: o programa pede o tamanho do vetor, e em seguida
*	o valor de cada um, e faz a soma e no final a media dos valores
*	
*
*	autor: Eno Paz Lopes
*		
*	data de cria��o 27/05/2026
*
==========================================================*/

#include <stdio.h>


int main () {
	int tamanho;
	
	int i;
	float soma = 0;
	float media;
	
	printf("digite o tamanho do vetor: ");
	scanf("%d", &tamanho);
	
	int vetor[tamanho];
	for(i = 0; i < tamanho; i++) {
		printf("digite o valor: ");
		scanf("%d", &vetor[i]);
		
		soma += vetor[i];
	}
	
	media = soma / tamanho;
	
	printf("a soma dos valores eh: %f \n", soma);
	printf("a media dos valores eh: %f", media);
	
	
	
	
	
	
	return 0;
}
