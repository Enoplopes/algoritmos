/*=========================================================
*
*	Nome do progroma: : Busca linear
*
*	objetivo: procurar o numero digitado dentro do vetor
*	
*
*	autor: Eno Paz Lopes
*		
*	data de cria��o 27/05/2026
*
==========================================================*/


#include <stdio.h>
#include <stdbool.h>

int main(){
	
	int vetor[6] = {10, 20, 30, 40, 50, 60};
	int i;
	int procurado;
	bool v = false;
	
	printf("Digite o numero que voce procura: ");
	scanf("%d", &procurado);
	
	for( i = 0 ; i < 6 ; i++){
		if(vetor[i] == procurado){
			printf("o numero procurado esta no indice %d", i);
			v = true;
		}
		
	}
	if (v == false){
		printf("numero nao encontrado");
	}
	
	
	
	
	
	return 0;
}
