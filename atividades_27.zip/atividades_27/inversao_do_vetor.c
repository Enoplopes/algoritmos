/*=========================================================
*
*	Nome do progroma: : Invers�o do Vetor
*
*	objetivo: invrter a ordem do vetor
*	
*
*	autor: Eno Paz Lopes
*		
*	data de cria��o 27/05/2026
*
==========================================================*/


#include <stdio.h>

int main() {
    int tamanho;

    printf("Digite a quantidade de elementos do vetor: ");
    scanf("%d", &tamanho);

    int vetor[tamanho];
    int i;
    printf("Digite os %d numeros:\n", tamanho);
    for ( i = 0; i < tamanho; i++) {
        printf("valor %d: ", i + 1);
        scanf("%d", &vetor[i]);
    }

    int inicio = 0;
    int fim = tamanho - 1;
    int aux;

    while (inicio < fim) {
        aux = vetor[inicio];       
        vetor[inicio] = vetor[fim]; 
        vetor[fim] = aux;          

        inicio++;
        fim--;
    }

    printf("\nVetor invertido: ");
    for (i = 0; i < tamanho; i++) {
        printf("%d ", vetor[i]);
    }
    

    return 0;
}
