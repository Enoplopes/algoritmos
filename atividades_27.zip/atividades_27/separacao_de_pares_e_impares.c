/*=========================================================
*
*	Nome do progroma: separacao de pares e impares
*
*	objetivo: separar os numeros impares e pares
*	
*	
*
*	autor: Eno Paz Lopes
*		
*	data de cria��o 27/05/2026
*
==========================================================*/


#include <stdio.h>

int main(){
	
	int vetor[10];
	int i;
	int par, impar;
	printf("Digite 10 numeros: \n");
	
	for( i = 0 ; i < 10 ; i++){
		printf("numero %d:", i + 1);
		scanf("%d", &vetor[i]);
		
	}
	
	printf("numeros pares: ", par);
	for(i = 0; i < 10; i++){
		
		if(vetor[i] % 2 == 0){
			par = vetor[i];
			printf(" %d, ", vetor[i]);
		}
	}
	printf("\nnumeros impares: ", impar);
	for(i = 0; i < 10; i++){
		
		if(vetor[i] % 2 != 0){
			impar = vetor[i];
			printf(" %d, ", vetor[i]);
		}
	}
	
	return 0;
}
