/*=========================================================
*
*	Nome do progroma: : Encontrar o Maior e o Menor Valor
*
*	objetivo: o programa pede o tamanho do vetor, e mostra
*	o maior valor digita dentro do vetor, e o menor valor
*	
*
*	autor: Eno Paz Lopes
*		
*	data de cria��o 27/05/2026
*
==========================================================*/

#include <stdio.h>
#include <limits.h>

int main(){

int tamanho;
int i;
int maior = INT_MIN;
int menor = INT_MAX;

	printf("digite o tamanho do vetor: ");
	scanf("%d", &tamanho);
int vetor[tamanho];

	printf("digite %d numeros", tamanho);
	
	for(i = 0; i < tamanho; i++) {
		printf("digite os valores: ");
		scanf("%d", &vetor[i]);
	}
	
	for(i = 0; i < tamanho; i++){
		if(vetor[i] > maior){
			maior = vetor[i];
		} if(vetor[i] < menor){
			menor = vetor[i];
		}
	}
	printf("o menor numero eh: %d \no maior numero eh: %d", menor, maior);
return 0;
}
