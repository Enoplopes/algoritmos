/*=========================================================
*
*	Nome do progroma: : organiza�ao crescente 
*
*	objetivo: organizar em ordem crescente os valores do vetor
*	
*
*	autor: Eno Paz Lopes
*		
*	data de cria��o 27/05/2026
*
==========================================================*/


#include <stdio.h>

int main() {
    int tamanho;

    printf("Digite a quantidade de elementos do vetor: ");
    scanf("%d", &tamanho);

    int vetor[tamanho];
    int i;
    int aux;
    int j;
    
    printf("Digite os %d numeros:\n", tamanho);
    for ( i = 0; i < tamanho; i++) {
        printf("valor %d: ", i + 1);
        scanf("%d", &vetor[i]);
    }
    for(i = 0; i < tamanho - 1; i++){
    	for(j = 0; i < tamanho -1; i++){ 	
			if (vetor[i] > vetor[i+1]){	
    			aux = vetor[i];
    			vetor[i] = vetor[i+1];
    			vetor[i+1] = aux;
    }
    }
}
    for(i = 0; i < tamanho; i++){
    
	printf("a order eh %d\n", vetor[i]);
}
    
    
    
    return 0;
}
